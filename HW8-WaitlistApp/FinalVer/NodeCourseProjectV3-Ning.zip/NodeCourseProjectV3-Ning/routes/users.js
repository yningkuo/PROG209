
var express = require('express');
var router = express.Router();

let serverMovieArray = []; // our "permanent storage" on the web server

// define a constructor to create movie objects
var MovieObject = function (pTitle, pYear, pGenre, pMan, pWoman) {
  this.Title = pTitle;
  this.Year = pYear;
  this.Genre = pGenre;  // action  comedy  drama  horrow scifi  musical  western
  this.Man = pMan;
  this.Woman = pWoman;
}

// for testing purposes, its nice to preload some data
serverMovieArray.push(new MovieObject("Kelly", "206-311-0015", "Table", "4","Birthday"));
serverMovieArray.push(new MovieObject("Laura", "213-456-2244", "High Chair", "2", ""));
serverMovieArray.push(new MovieObject("Cameron", "310-487-5487", "Table", "5", "With baby"));
serverMovieArray.push(new MovieObject("Bern", "425-310-2244", "Indoor", "2", "Engage"));
serverMovieArray.push(new MovieObject("Betty", "810-322-5488", "Bar", "1", ""));


/* POST to addMovie */
router.post('/addMovie', function(req, res) {
  console.log(req.body);
  serverMovieArray.push(req.body);
  console.log(serverMovieArray);
  //res.sendStatus(200);
  res.status(200).send(JSON.stringify('success'));
});


/* GET movieList. */
router.get('/movieList', function(req, res) {
  res.json(serverMovieArray);
 });

 /* DELETE to deleteMovie. */
 router.delete('/deleteMovie/:Title', function(req, res) {
  let Title = req.params.Title;
  Title = Title.toLowerCase();  // allow user to be careless about capitalization
  console.log('deleting ID: ' + Title);
   for(let i=0; i < serverMovieArray.length; i++) {
     if(Title == (serverMovieArray[i].Title).toLowerCase()) {
     serverMovieArray.splice(i,1);
     }
   }
   res.status(200).send(JSON.stringify('deleted successfully'));
});


//  router.???('/userlist', function(req, res) {
//  users.update({name: 'foo'}, {name: 'bar'})



module.exports = router;

